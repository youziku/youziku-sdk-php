<?php

    //接口方法
    class ServiceMethod
    {
  
        //接口方法GetFontFace()
        const  GetFontface = "/webFont/getFontFace";
 
        //接口方法GetWoffBase64StringFontFace()
        const  GetWoffBase64StringFontFace = "/webFont/getWoffBase64StringFontFace";

        //接口方法GetBatchFontFace()
        const  GetBatchFontFace = "/batchWebFont/getBatchFontFace";

        //接口方法CreateBatchWoffWebFontAsync()
        const  CreateBatchWoffWebFont = "/batchCustomWebFont/createBatchWoffWebFontAsync";
        
    }

?>